from django.apps import AppConfig


class CallDataDashboardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'call_data_dashboard'
