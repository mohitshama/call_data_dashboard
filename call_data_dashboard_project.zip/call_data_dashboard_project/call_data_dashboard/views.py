from django.shortcuts import render
from .models import CallData
from django.db.models import Count, Avg, Q

def kpi_dashboard(request):
    # Calculate total number of calls by operator
    total_calls_by_operator = CallData.objects.values('operator').annotate(total=Count('id'))

    # Calculate average call rating by operator
    avg_rating_by_operator = CallData.objects.values('operator').annotate(average_rating=Avg('rating'))

    # Calculate the call drop rate by network type
    call_drop_by_network = CallData.objects.values('network_type').annotate(
        total_calls=Count('id'),
        call_drops=Count('id', filter=Q(calldrop_category='Call Dropped'))
    )

    call_drop_rate_by_network = []
    for entry in call_drop_by_network:
        network_type = entry['network_type']
        total_calls = entry['total_calls']
        call_drops = entry['call_drops']
        if total_calls > 0:
            drop_rate = (call_drops / total_calls) * 100  # Convert to percentage
        else:
            drop_rate = 0  # Avoid division by zero

        call_drop_rate_by_network.append({
            'network_type': network_type,
            'drop_rate': drop_rate
        })

    # Retrieve call locations for the map
    call_locations = CallData.objects.filter(latitude__gt=0, longitude__gt=0).values('latitude', 'longitude')

    context = {
        'total_calls_by_operator': total_calls_by_operator,
        'avg_rating_by_operator': avg_rating_by_operator,
        'call_drop_rate_by_network': call_drop_rate_by_network,
        'call_locations': call_locations,  # Add this to the context
    }

    return render(request, 'kpi_dashboard.html', context)
