from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import CallData  # Import your model

@admin.register(CallData)
class CallDataAdmin(ImportExportModelAdmin):
    pass

# Register your models here.
