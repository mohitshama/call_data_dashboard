from django.core.management.base import BaseCommand
from call_data_dashboard.models import CallData  # Import your model

class Command(BaseCommand):
    help = 'Load custom data into the database'

    def handle(self, *args, **options):
        data = [
            {
                'operator': 'BSNL',
                'inout_travelling': 'Indoor',
                'network_type': '3G',
                'rating': 3,
                'calldrop_category': 'Satisfactory',
                'latitude': -1,
                'longitude': -1,
                'state_name': 'NA',
            },
            # Add more data entries as needed
        ]

        for item in data:
            call_data = CallData(**item)
            call_data.save()

        self.stdout.write(self.style.SUCCESS('Data loaded successfully'))
