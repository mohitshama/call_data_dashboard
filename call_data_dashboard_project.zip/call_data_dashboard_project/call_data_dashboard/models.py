from django.db import models

class CallData(models.Model):
    operator = models.CharField(max_length=100)
    inout_travelling = models.CharField(max_length=100)
    network_type = models.CharField(max_length=100)
    rating = models.IntegerField()
    calldrop_category = models.CharField(max_length=100)
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    state_name = models.CharField(max_length=100)


# Create your models here.
